import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class DatasetGenerator {

    private static final String[] FIRST_NAMES = {
        "Alex", "Chris", "Daniel", "Emily", "Sarah", "Jessica", "Michael", "Ryan",
        "Matthew", "Ethan", "Olivia", "Sophia", "Emma", "Isabella", "Ava", "Mia",
        "Noah", "James", "Benjamin", "Lucas", "Henry", "Jacob", "William", "Logan",
        "Grace", "Hannah", "Lily", "Zoe", "Natalie", "Anna"
    };

    private static final String[] LAST_NAMES = {
        "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller",
        "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez",
        "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin"
    };

    // MAIN METHOD
    public static void generateCSV(String filename, int size) throws IOException {
        Random rand = new Random();
        FileWriter writer = new FileWriter(filename);

        // HEADER
        writer.write("ID,FirstName,LastName,GPA,Grade\n");

        for (int i = 0; i < size; i++) {
            int id = generateID(rand);
            String first = generateFirstName(rand);
            String last = generateLastName(rand);
            double gpa = generateGPA(rand);
            int grade = generateGrade(rand);

            writer.write(id + "," + first + "," + last + "," + gpa + "," + grade + "\n");
        }

        writer.close();
        System.out.println("Generated " + size + " records in " + filename);
    }

    // STUDENT ID GENERATION
    private static int generateID(Random rand) {
        return 100000 + rand.nextInt(900000);
    }

    // GPA GENERATION
    private static double generateGPA(Random rand) {
        double mean = 3.2;
        double stdDev = 0.35;
        double gpa;

        do {
            gpa = mean + rand.nextGaussian() * stdDev;
        } while (gpa < 0.0 || gpa > 4.0);

        return Math.round(gpa * 100.0) / 100.0;
    }

    // FIRST NAME RANDOM
    private static String generateFirstName(Random rand) {
        return FIRST_NAMES[rand.nextInt(FIRST_NAMES.length)];
    }

    // LAST NAME RANDOM
    private static String generateLastName(Random rand) {
        return LAST_NAMES[rand.nextInt(LAST_NAMES.length)];
    }

    // GRADE LEVEL GENERATION (grades 9-12)
    private static int generateGrade(Random rand) {
        return 9 + rand.nextInt(4);
    }
}