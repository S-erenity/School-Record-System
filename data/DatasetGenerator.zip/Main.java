import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            // SMALL 100 records
            DatasetGenerator.generateCSV("students_small.csv", 100);

            // MEDIUM 1,000 records
            DatasetGenerator.generateCSV("students_medium.csv", 1000);

            // LARGE 10,000 records
            DatasetGenerator.generateCSV("students_large.csv", 10000);

        } catch (IOException e) {
            System.out.println("Error generating CSV: " + e.getMessage());
        }
    }
}